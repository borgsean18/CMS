<?php
/********************* META BOX DEFINITIONS ***********************/

/**
 * Prefix of meta keys (optional)
 * Use underscore (_) at the beginning to make keys hidden
 * Alt.: You also can make prefix empty to disable it
 */
// Better has an underscore as last sign
$prefix = 'shadowfiend_';

$meta_boxes = array();

// Post Layout Options
$meta_boxes[] = array(
    'id' => "{$prefix}post_fullwidth",
    'title' => esc_html__( 'shadowfiend Post Option', 'zalora'),
    'pages' => array( 'post' ),
    'context' => 'normal',
    'priority' => 'high',

    'fields' => array(
        array(
			'id' => "{$prefix}post_layout",
            'name' => esc_html__( 'Post Layout Option', 'zalora'),
			'desc' => esc_html__('Setup Post Layout', 'zalora'),
            'type' => 'select', 
			'options'  => array(
                            'standard' => esc_html__( 'Standard', 'zalora'),
                            'feat-fw' => esc_html__( 'Feature Image Full Width', 'zalora'),
                            'no-sidebar' => esc_html__('No Sidebar', 'zalora'), 
    				    ),
			// Select multiple values, optional. Default is false.
			'multiple'    => false,
			'std'         => 'standard',
		),
    )
);
// Page Layout Options
$meta_boxes[] = array(
    'id' => "{$prefix}page_fullwidth",
    'title' => esc_html__( 'shadowfiend Page Option', 'zalora'),
    'pages' => array( 'page' ),
    'context' => 'normal',
    'priority' => 'high',

    'fields' => array(
        // Enable Review
        array(
            'name' => esc_html__( 'Make this page full-width', 'zalora'),
            'id' => "{$prefix}page_fullwidth_checkbox",
            'type' => 'checkbox',
            'std'  => 0,
        ),
    )
);
// 2nd meta box
$meta_boxes[] = array(
    'id' => "{$prefix}format_options",
    'title' => esc_html__( 'shadowfiend Post Format Options', 'zalora'),
    'pages' => array( 'post' ),
    'context' => 'normal',
    'priority' => 'high',
	'fields' => array(        
        //Video
        array(
            'name' => esc_html__( 'Format Options: Video, Audio', 'zalora'),
            'desc' => esc_html__('Support Youtube, Vimeo, SoundCloud, DailyMotion, ... iframe embed code', 'zalora'),
            'id' => "{$prefix}media_embed_code_post",
            'type' => 'textarea',
            'placeholder' => esc_html__('Link ...', 'zalora'),
            'std' => ''
        ),
		// PLUPLOAD IMAGE UPLOAD (WP 3.3+)
		array(
			'name'             => esc_html__( 'Format Options: Image', 'zalora'),
            'desc'             => esc_html__('Image Upload', 'zalora'),
			'id'               => "{$prefix}image_upload",
			'type'             => 'plupload_image',
			'max_file_uploads' => 1,
		),
        //Gallery
        array(
            'name' => esc_html__( 'Format Options: Gallery', 'zalora'),
            'desc' => esc_html__('Gallery Images', 'zalora'),
            'id' => "{$prefix}gallery_content",
            'type' => 'image_advanced',
            'std' => ''
        )
    )
);
// Post Review Options
$meta_boxes[] = array(
    'id' => "{$prefix}review",
    'title' => esc_html__( 'shadowfiend Review System', 'zalora'),
    'pages' => array( 'post' ),
    'context' => 'normal',
    'priority' => 'high',

    'fields' => array(
        // Enable Review
        array(
            'name' => esc_html__( 'Include Review Box', 'zalora'),
            'id' => "{$prefix}review_checkbox",
            'type' => 'checkbox',
            'desc' => esc_html__( 'Enable Review On This Post', 'zalora'),
            'std'  => 0,
        ),
        // Criteria 1 Text & Score
        array(
            'name'  => esc_html__( 'Criteria 1 Title', 'zalora'),
            'id'    => "{$prefix}ct1",
            'type'  => 'text',
        ),
        array(
            'name' => esc_html__( 'Criteria 1 Score', 'zalora'),
            'id' => "{$prefix}cs1",
            'type' => 'slider',
            'js_options' => array(
                'min'   => 0,
                'max'   => 10,
                'step'  => .1,
            ),
        ),
        // Criteria 2 Text & Score
        array(
            'name'  => esc_html__( 'Criteria 2 Title', 'zalora'),
            'id'    => "{$prefix}ct2",
            'type'  => 'text',
        ),
        array(
            'name' => esc_html__( 'Criteria 2 Score', 'zalora'),
            'id' => "{$prefix}cs2",
            'type' => 'slider',
            'js_options' => array(
                'min'   => 0,
                'max'   => 10,
                'step'  => .1,
            ),
        ),    
        // Criteria 3 Text & Score
        array(
            'name'  => esc_html__( 'Criteria 3 Title', 'zalora'),
            'id'    => "{$prefix}ct3",
            'type'  => 'text',
        ),
        array(
            'name' => esc_html__( 'Criteria 3 Score', 'zalora'),
            'id' => "{$prefix}cs3",
            'type' => 'slider',
            'js_options' => array(
                'min'   => 0,
                'max'   => 10,
                'step'  => .1,
            ),
        ),
        // Criteria 4 Text & Score
        array(
            'name'  => esc_html__( 'Criteria 4 Title', 'zalora'),
            'id'    => "{$prefix}ct4",
            'type'  => 'text',
        ),
        array(
            'name' => esc_html__( 'Criteria 4 Score', 'zalora'),
            'id' => "{$prefix}cs4",
            'type' => 'slider',
            'js_options' => array(
                'min'   => 0,
                'max'   => 10,
                'step'  => .1,
            ),
        ),
        // Criteria 5 Text & Score
        array(
            'name'  => esc_html__( 'Criteria 5 Title', 'zalora'),
            'id'    => "{$prefix}ct5",
            'type'  => 'text',
        ),
        array(
            'name' => esc_html__( 'Criteria 5 Score', 'zalora'),
            'id' => "{$prefix}cs5",
            'type' => 'slider',
            'js_options' => array(
                'min'   => 0,
                'max'   => 10,
                'step'  => .1,
            ),
        ),    
        // Criteria 6 Text & Score
        array(
            'name'  => esc_html__( 'Criteria 6 Title', 'zalora'),
            'id'    => "{$prefix}ct6",
            'type'  => 'text',
        ),
        array(
            'name' => esc_html__( 'Criteria 6 Score', 'zalora'),
            'id' => "{$prefix}cs6",
            'type' => 'slider',
            'js_options' => array(
                'min'   => 0,
                'max'   => 10,
                'step'  => .1,
            ),
        ),
        // Summary
        array(
            'name' => esc_html__( 'Summary', 'zalora'),
            'id'   => "{$prefix}summary",
            'type' => 'textarea',
            'cols' => 20,
            'rows' => 4,
        ),
        
        // Final average
        array(
            'name'  => esc_html__('Final Average Score','zalora'),
            'id'    => "{$prefix}final_score",
            'type'  => 'text',
        ),
        
        array(
			'id' => "{$prefix}review_box_position",
            'name' => esc_html__( 'Review Box Position', 'zalora'),
			'desc' => esc_html__('Setup review post position [left-content, right-content, above-content, below-content]', 'zalora'),
            'type' => 'select', 
			'options'  => array(
        					'left' => esc_html__( 'Left', 'zalora'),
        					'right' => esc_html__( 'Right ', 'zalora'),
                            'above' => esc_html__( 'Top', 'zalora'),
                            'below' => esc_html__( 'Bottom', 'zalora'),
    				    ),
			// Select multiple values, optional. Default is false.
			'multiple'    => false,
			'std'         => 'left',
		),
    )
);
/********************* META BOX REGISTERING ***********************/

/**
 * Register meta boxes
 *
 * @return void
 */
if ( ! function_exists( 'shadowfiend_register_meta_boxes' ) ) {
    function shadowfiend_register_meta_boxes() {
    	// Make sure there's no errors when the plugin is deactivated or during upgrade
    	if ( !class_exists( 'RW_Meta_Box' ) )
    		return;
    
    	global $meta_boxes;
    	foreach ( $meta_boxes as $meta_box )
    	{
    		new RW_Meta_Box( $meta_box );
    	}
    }
}
// Hook to 'admin_init' to make sure the meta box class is loaded before
// (in case using the meta box class in another plugin)
// This is also helpful for some conditionals like checking page template, categories, etc.
add_action( 'admin_init', 'shadowfiend_register_meta_boxes' );
